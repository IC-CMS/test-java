package com.capitalone.dashboard.collector;


public class DefaultHpsmClientTest {
}
