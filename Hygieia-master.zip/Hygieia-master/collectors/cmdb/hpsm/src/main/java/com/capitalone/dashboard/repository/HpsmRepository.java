package com.capitalone.dashboard.repository;

import com.capitalone.dashboard.model.HpsmCollector;
/**
 * Repository for {@link HpsmCollector}.
 */
public interface HpsmRepository extends BaseCollectorRepository<HpsmCollector> {

}
