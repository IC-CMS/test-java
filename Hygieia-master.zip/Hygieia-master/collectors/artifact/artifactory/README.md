The README is in the [gh-pages](https://github.com/capitalone/Hygieia/blob/gh-pages/pages/hygieia/collectors/artifact/artifactory.md) branch. Please update it there.
